<html>
<head>
    <title>
        FFCDS :) Fully Flexible Credit Debit System
    </title>
    <style>
    img {
    width :50%
        }
    td
        {
            text-align: center;
            
        }
        img{
            padding: 10px;
        }
  img:hover 
        {
            border: 1px solid green;
            padding: 10px;
           
        }
        hr{
            width: 90%;
        }
        Button{
            border: 42px solid #4CAF50;border-radius: 120px; padding:90px;padding-top:40;padding-bottom:40;margin:auto;
            
        }
        a{
            text-decoration: none;
            font-family: Georgia, serif;
        }
    </style>
</head>

<body>

    <h1>
        <br>
        <br>
        <center>
    FFCDS :) Fully Flexible Credit Debit System
            </center>
       </h1>
        <br>
    
      <br>
    <br>
      <br>
    <br>
    <br>
      <br>
    <br><br>
    
    &nbsp;
    &nbsp;
    &nbsp;
    &nbsp; 
    &nbsp;
    &nbsp;
    &nbsp;
    &nbsp;
    &nbsp;
    &nbsp;
    
    &nbsp;
    &nbsp;
    &nbsp; 
    &nbsp;
    &nbsp;
    &nbsp;
    &nbsp;
    &nbsp;
        <button style='margin-right:260px' 'margin-left:40px'>
     <a  href="adlogin.php">
         <h1>Admin Login</h1>
            </a>
         </button>
        
 <button style='margin-right:110px''margin-left:10px' ><a href="login.php"><h1>Student Login</h1> </a></button>
</body>
</html>