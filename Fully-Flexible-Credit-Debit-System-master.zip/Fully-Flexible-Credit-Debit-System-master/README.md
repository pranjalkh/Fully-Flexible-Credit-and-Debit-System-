# Fully Flexible Credit Debit System
 A payment system for students/employers inside campus.

To avoid the hassle of cash payments inside campus, we are introducing the concept of Fully Flexible Credit - Debit System (FFCDS) using VIT ID card, which will help Vitians to pay for shops inside VIT. This works on the principle of access control, enabling students to pay using their own ID card authenticated by their secure pin.
To practicalize this idea we have following flow of events, first the user selects the store whom he/she wants to pay, which is followed by a secure login. The admin has the privilege to add user as well as to add money in user’s account. 

To practicalize this idea we have following flow of events, first the user selects the store whom he/she wants to pay, which is followed by a secure login. The admin has the privilege to add user as well as to add money in user’s account. 

To have a better understanding of the project, you can see the Final report doc.


NOTE: There are many bugs and there can be many improvements in the design specially the UI. The project is more about pitching an idea than a real implementation of the same.